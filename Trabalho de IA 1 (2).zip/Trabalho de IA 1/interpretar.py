import argparse
import re


BLOCOS = {
    "a": 1,
    "b": 1,
    "c": 2,
    "d": 3
}

ARQUIVO_MAPA = "trab01_blocos2SAT.map"


def ler_mapa():
    mapa = {}

    with open(ARQUIVO_MAPA, "r", encoding="utf-8") as arquivo:
        for linha in arquivo:
            linha = linha.strip()

            if not linha:
                continue

            partes = linha.split(maxsplit=1)

            if len(partes) == 2:
                mapa[int(partes[0])] = partes[1]

    return mapa


def ler_resultado(nome_arquivo):
    with open(nome_arquivo, "r", encoding="utf-8") as arquivo:
        conteudo = arquivo.read().split()

    if "UNSAT" in conteudo or "UNSATISFIABLE" in conteudo:
        return False, []

    if "SAT" not in conteudo and "SATISFIABLE" not in conteudo:
        raise ValueError("Resultado SAT não reconhecido.")

    literais = []

    for item in conteudo:
        try:
            valor = int(item)

            if valor > 0:
                literais.append(valor)

        except ValueError:
            pass

    return True, literais


def parametros(simbolo, predicado):
    correspondencia = re.match(
        rf"^{predicado}\((.*)\)$",
        simbolo
    )

    if not correspondencia:
        return None

    return [
        valor.strip()
        for valor in correspondencia.group(1).split(",")
    ]


def extrair_movimentos(mapa, literais):
    movimentos = []

    for identificador in literais:
        simbolo = mapa.get(identificador)

        if not simbolo:
            continue

        dados = parametros(simbolo, "move")

        if not dados or len(dados) != 4:
            continue

        movimentos.append({
            "bloco": dados[0],
            "destino": dados[1],
            "ponto": int(dados[2]),
            "tempo": int(dados[3])
        })

    movimentos.sort(
        key=lambda movimento: movimento["tempo"]
    )

    return movimentos


def descobrir_tempo_final(mapa, literais):
    tempo_final = 0

    for identificador in literais:
        simbolo = mapa.get(identificador)

        if not simbolo:
            continue

        dados = parametros(simbolo, "at")

        if dados:
            tempo_final = max(
                tempo_final,
                int(dados[2])
            )

    return tempo_final


def extrair_estado_final(mapa, literais, tempo_final):
    posicoes = {}
    niveis = {}

    for identificador in literais:
        simbolo = mapa.get(identificador)

        if not simbolo:
            continue

        dados = parametros(simbolo, "at")

        if dados:
            bloco = dados[0]
            ponto = int(dados[1])
            tempo = int(dados[2])

            if tempo == tempo_final:
                posicoes[bloco] = ponto

            continue

        dados = parametros(simbolo, "lev")

        if dados:
            bloco = dados[0]
            altura = int(dados[1])
            tempo = int(dados[2])

            if tempo == tempo_final:
                niveis[bloco] = altura

    estado_final = {}

    for bloco in BLOCOS:
        if bloco in posicoes and bloco in niveis:
            estado_final[bloco] = (
                posicoes[bloco],
                niveis[bloco]
            )

    return estado_final


def sobrepoe(bloco1, ponto1, bloco2, ponto2):
    fim1 = ponto1 + BLOCOS[bloco1]
    fim2 = ponto2 + BLOCOS[bloco2]

    return ponto1 < fim2 and ponto2 < fim1


def derivar_on(estado_final):
    relacoes = {}

    for bloco, (ponto, altura) in estado_final.items():

        if altura == 0:
            relacoes[bloco] = ["T"]
            continue

        apoios = []

        for outro, (ponto_outro, altura_outro) in estado_final.items():

            if outro == bloco:
                continue

            if altura_outro != altura - 1:
                continue

            if sobrepoe(
                bloco,
                ponto,
                outro,
                ponto_outro
            ):
                apoios.append(outro)

        relacoes[bloco] = apoios

    return relacoes


def mostrar_plano(movimentos):
    print(f"\nPLANO ENCONTRADO ({len(movimentos)} acoes):\n")

    for numero, movimento in enumerate(movimentos, start=1):

        bloco = movimento["bloco"]
        destino = movimento["destino"]
        ponto = movimento["ponto"]
        tempo = movimento["tempo"]

        if destino == "T":
            print(
                f"{numero}. t={tempo}: mover bloco '{bloco}' "
                f"para a MESA em p={ponto}"
            )
        else:
            print(
                f"{numero}. t={tempo}: mover bloco '{bloco}' "
                f"para CIMA de '{destino}' em p={ponto}"
            )


def mostrar_estado_final(estado_final, tempo_final):
    print(f"\nESTADO FINAL (t={tempo_final}):\n")

    for bloco in sorted(estado_final):
        ponto, altura = estado_final[bloco]

        print(
            f"{bloco}: ponto inicial p={ponto}, "
            f"nivel l={altura}"
        )


def mostrar_relacoes(relacoes):
    print("\nRELACOES 'on':\n")

    for bloco in sorted(relacoes):
        apoios = relacoes[bloco]

        if apoios == ["T"]:
            print(f"{bloco} esta na MESA")

        elif len(apoios) == 1:
            print(f"{bloco} esta sobre: {apoios[0]}")

        elif len(apoios) > 1:
            print(
                f"{bloco} esta sobre: "
                + ", ".join(apoios)
            )

        else:
            print(f"{bloco}: nenhum apoio encontrado")


def mostrar_variaveis(mapa, literais):
    print("\nVARIAVEIS VERDADEIRAS:\n")

    for identificador in sorted(literais):
        simbolo = mapa.get(identificador)

        if simbolo:
            print(f"{identificador}: {simbolo}")


def main():
    analisador = argparse.ArgumentParser()

    analisador.add_argument(
        "resultado",
        help="arquivo de resultado do SAT solver"
    )

    analisador.add_argument(
        "--verbose",
        action="store_true"
    )

    argumentos = analisador.parse_args()

    mapa = ler_mapa()

    satisfativel, literais = ler_resultado(
        argumentos.resultado
    )

    if not satisfativel:
        print("UNSATISFIABLE")
        print("Nao existe plano para este horizonte.")
        return

    movimentos = extrair_movimentos(
        mapa,
        literais
    )

    tempo_final = descobrir_tempo_final(
        mapa,
        literais
    )

    estado_final = extrair_estado_final(
        mapa,
        literais,
        tempo_final
    )

    relacoes = derivar_on(
        estado_final
    )

    mostrar_plano(movimentos)
    mostrar_estado_final(
        estado_final,
        tempo_final
    )
    mostrar_relacoes(relacoes)

    if argumentos.verbose:
        mostrar_variaveis(
            mapa,
            literais
        )


if __name__ == "__main__":
    main()