import os
import subprocess
import sys


PASTA_PROJETO = os.path.dirname(
    os.path.abspath(__file__)
)

ARQUIVO_GERADOR = os.path.join(
    PASTA_PROJETO,
    "bw2cnf_var.py"
)

ARQUIVO_SOLVER = os.path.join(
    PASTA_PROJETO,
    "solver.py"
)

ARQUIVO_INTERPRETADOR = os.path.join(
    PASTA_PROJETO,
    "interpretar.py"
)

ARQUIVO_RESULTADO = os.path.join(
    PASTA_PROJETO,
    "resultado1.txt"
)


def executar_horizonte(horizonte, mostrar=True):
    ambiente = os.environ.copy()
    ambiente["HORIZONTE"] = str(horizonte)

    geracao = subprocess.run(
        [
            sys.executable,
            ARQUIVO_GERADOR
        ],
        env=ambiente,
        cwd=PASTA_PROJETO,
        capture_output=True,
        text=True
    )

    if geracao.returncode != 0:
        print("\nErro ao gerar o arquivo CNF:")
        print(geracao.stderr)
        return None

    if mostrar:
        print("\n" + geracao.stdout.strip())

    solucao = subprocess.run(
        [
            sys.executable,
            ARQUIVO_SOLVER
        ],
        cwd=PASTA_PROJETO,
        capture_output=True,
        text=True
    )

    if solucao.returncode != 0:
        print("\nErro ao executar o solver:")
        print(solucao.stderr)
        return None

    try:
        with open(
            ARQUIVO_RESULTADO,
            "r",
            encoding="utf-8"
        ) as arquivo:
            resultado = arquivo.readline().strip()

    except FileNotFoundError:
        print("\nArquivo resultado1.txt não encontrado.")
        return None

    if resultado == "SAT":
        return True

    if resultado == "UNSAT":
        return False

    print("\nResultado do solver não reconhecido.")
    return None


def mostrar_plano(verbose=False):
    comando = [
        sys.executable,
        ARQUIVO_INTERPRETADOR,
        ARQUIVO_RESULTADO
    ]

    if verbose:
        comando.append("--verbose")

    subprocess.run(
        comando,
        cwd=PASTA_PROJETO
    )


def resolver_horizonte():
    try:
        horizonte = int(
            input("\nDigite o horizonte: ")
        )

    except ValueError:
        print("\nDigite um número inteiro.")
        return

    if horizonte < 0:
        print("\nO horizonte não pode ser negativo.")
        return

    print(
        f"\nTestando horizonte T = {horizonte}..."
    )

    resultado = executar_horizonte(
        horizonte
    )

    if resultado is True:
        print("\nSATISFIABLE")
        print("Plano encontrado.")

        resposta = input(
            "\nMostrar todas as variáveis "
            "verdadeiras? (s/n): "
        ).strip().lower()

        mostrar_plano(
            resposta == "s"
        )

    elif resultado is False:
        print("\nUNSATISFIABLE")
        print(
            f"Não existe plano com horizonte "
            f"{horizonte}."
        )


def procurar_menor_horizonte():
    entrada = input(
        "\nHorizonte máximo para busca "
        "(Enter para usar 10): "
    ).strip()

    if entrada == "":
        horizonte_maximo = 10

    else:
        try:
            horizonte_maximo = int(
                entrada
            )

        except ValueError:
            print("\nDigite um número inteiro.")
            return

    if horizonte_maximo < 0:
        print(
            "\nO horizonte máximo não pode "
            "ser negativo."
        )
        return

    print("\nProcurando o menor horizonte\n")

    encontrado = None

    for horizonte in range(
        horizonte_maximo + 1
    ):
        print(
            f"Testando T = {horizonte}...",
            end=" "
        )

        resultado = executar_horizonte(
            horizonte,
            mostrar=False
        )

        if resultado is True:
            print("SAT")
            encontrado = horizonte
            break

        if resultado is False:
            print("UNSAT")

        else:
            print("ERRO")
            return

    if encontrado is None:
        print(
            f"\nNenhum plano encontrado até "
            f"T = {horizonte_maximo}."
        )
        return

    print(
        f"\nMenor horizonte encontrado: "
        f"T = {encontrado}"
    )

    resposta = input(
        "\nMostrar todas as variáveis "
        "verdadeiras? (s/n): "
    ).strip().lower()

    mostrar_plano(
        resposta == "s"
    )


def menu():
    while True:
        print("\n-------------------------------")
        print("Mundo dos Blocos - SAT Solver")
        print("-------------------------------")
        print("1 - Resolver com horizonte escolhido")
        print("2 - Procurar o menor horizonte")
        print("3 - Sair")

        opcao = input(
            "\nEscolha uma opção: "
        ).strip()

        if opcao == "1":
            resolver_horizonte()

        elif opcao == "2":
            procurar_menor_horizonte()

        elif opcao == "3":
            print("\nPrograma encerrado.")
            break

        else:
            print("\nOpção inválida.")


if __name__ == "__main__":
    menu()