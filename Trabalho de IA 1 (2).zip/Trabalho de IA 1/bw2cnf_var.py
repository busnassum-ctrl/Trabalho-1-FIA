import os
from itertools import combinations


BLOCOS = {
    "a": 1,
    "b": 1,
    "c": 2,
    "d": 3
}

PONTO_MAXIMO = 6
NIVEL_MAXIMO = 3

HORIZONTE = int(
    os.environ.get("HORIZONTE", 4)
)

ESTADO_INICIAL = {
    "c": (0, 0),
    "a": (3, 0),
    "b": (5, 0),
    "d": (3, 1)
}

ESTADO_META = {
    "c": (0, 0),
    "a": (0, 1),
    "d": (2, 0),
    "b": (5, 0)
}

ARQUIVO_CNF = "trab01_blocos2SAT.cnf"
ARQUIVO_MAPA = "trab01_blocos2SAT.map"


proxima_variavel = 1
mapa_variaveis = {}
clausulas = []

posicao = {}
nivel = {}
livre = {}
movimento = {}

estado = {}
ocupado_slot = {}


def nova_variavel(nome):
    global proxima_variavel

    identificador = proxima_variavel
    proxima_variavel += 1

    mapa_variaveis[identificador] = nome

    return identificador


def posicoes_validas(comprimento):
    return range(
        PONTO_MAXIMO - comprimento + 1
    )


def sobrepoe(bloco1, ponto1, bloco2, ponto2):
    fim1 = ponto1 + BLOCOS[bloco1]
    fim2 = ponto2 + BLOCOS[bloco2]

    return ponto1 < fim2 and ponto2 < fim1


def cobre_slot(bloco, ponto, slot):
    return ponto <= slot < ponto + BLOCOS[bloco]


def exatamente_uma(variaveis):
    clausulas.append(list(variaveis))

    for i in range(len(variaveis)):
        for j in range(i + 1, len(variaveis)):
            clausulas.append([
                -variaveis[i],
                -variaveis[j]
            ])


def pelo_menos_k(condicao, variaveis, quantidade):
    total = len(variaveis)

    if quantidade <= 0:
        return

    if quantidade > total:
        clausulas.append([-condicao])
        return

    tamanho = total - quantidade + 1

    for grupo in combinations(
        variaveis,
        tamanho
    ):
        clausulas.append(
            [-condicao] + list(grupo)
        )


# Variaveis de posicao
for bloco, comprimento in BLOCOS.items():

    for tempo in range(HORIZONTE + 1):

        for ponto in posicoes_validas(comprimento):

            nome = f"at({bloco},{ponto},{tempo})"

            posicao[
                (bloco, ponto, tempo)
            ] = nova_variavel(nome)


# Variaveis de nivel
for bloco in BLOCOS:

    for tempo in range(HORIZONTE + 1):

        for altura in range(NIVEL_MAXIMO + 1):

            nome = f"lev({bloco},{altura},{tempo})"

            nivel[
                (bloco, altura, tempo)
            ] = nova_variavel(nome)


# Variaveis clr
for bloco in BLOCOS:

    for tempo in range(HORIZONTE + 1):

        nome = f"clr({bloco},{tempo})"

        livre[
            (bloco, tempo)
        ] = nova_variavel(nome)


# Variaveis de movimento
for bloco, comprimento in BLOCOS.items():

    destinos = list(BLOCOS.keys()) + ["T"]

    for destino in destinos:

        if destino == bloco:
            continue

        for tempo in range(HORIZONTE):

            for ponto in posicoes_validas(comprimento):

                nome = (
                    f"move("
                    f"{bloco},"
                    f"{destino},"
                    f"{ponto},"
                    f"{tempo})"
                )

                movimento[
                    (bloco, destino, ponto, tempo)
                ] = nova_variavel(nome)


# Estado = posicao + nivel
for bloco, comprimento in BLOCOS.items():

    for tempo in range(HORIZONTE + 1):

        for ponto in posicoes_validas(comprimento):

            for altura in range(NIVEL_MAXIMO + 1):

                nome = (
                    f"estado("
                    f"{bloco},"
                    f"{ponto},"
                    f"{altura},"
                    f"{tempo})"
                )

                var_estado = nova_variavel(nome)

                estado[
                    (bloco, ponto, altura, tempo)
                ] = var_estado

                var_posicao = posicao[
                    (bloco, ponto, tempo)
                ]

                var_nivel = nivel[
                    (bloco, altura, tempo)
                ]

                clausulas.append([
                    -var_estado,
                    var_posicao
                ])

                clausulas.append([
                    -var_estado,
                    var_nivel
                ])

                clausulas.append([
                    -var_posicao,
                    -var_nivel,
                    var_estado
                ])


# Slots ocupados
for tempo in range(HORIZONTE + 1):

    for altura in range(NIVEL_MAXIMO + 1):

        for slot in range(PONTO_MAXIMO):

            nome = (
                f"ocupado_slot("
                f"{slot},"
                f"{altura},"
                f"{tempo})"
            )

            var_ocupado = nova_variavel(nome)

            ocupado_slot[
                (slot, altura, tempo)
            ] = var_ocupado

            estados_cobrindo = []

            for bloco, comprimento in BLOCOS.items():

                for ponto in posicoes_validas(comprimento):

                    if cobre_slot(
                        bloco,
                        ponto,
                        slot
                    ):

                        var_estado = estado[
                            (
                                bloco,
                                ponto,
                                altura,
                                tempo
                            )
                        ]

                        estados_cobrindo.append(
                            var_estado
                        )

                        clausulas.append([
                            -var_estado,
                            var_ocupado
                        ])

            clausulas.append(
                [-var_ocupado]
                + estados_cobrindo
            )


# Estado inicial
for bloco, (ponto, altura) in ESTADO_INICIAL.items():

    clausulas.append([
        posicao[
            (bloco, ponto, 0)
        ]
    ])

    clausulas.append([
        nivel[
            (bloco, altura, 0)
        ]
    ])


# Estado meta
for bloco, (ponto, altura) in ESTADO_META.items():

    clausulas.append([
        posicao[
            (bloco, ponto, HORIZONTE)
        ]
    ])

    clausulas.append([
        nivel[
            (bloco, altura, HORIZONTE)
        ]
    ])


# Unicidade de posicao
for bloco, comprimento in BLOCOS.items():

    for tempo in range(HORIZONTE + 1):

        variaveis = []

        for ponto in posicoes_validas(comprimento):

            variaveis.append(
                posicao[
                    (bloco, ponto, tempo)
                ]
            )

        exatamente_uma(
            variaveis
        )


# Unicidade de nivel
for bloco in BLOCOS:

    for tempo in range(HORIZONTE + 1):

        variaveis = []

        for altura in range(NIVEL_MAXIMO + 1):

            variaveis.append(
                nivel[
                    (bloco, altura, tempo)
                ]
            )

        exatamente_uma(
            variaveis
        )


# Exclusao horizontal
lista_blocos = list(BLOCOS.keys())

for tempo in range(HORIZONTE + 1):

    for altura in range(NIVEL_MAXIMO + 1):

        for i in range(len(lista_blocos)):

            for j in range(i + 1, len(lista_blocos)):

                bloco1 = lista_blocos[i]
                bloco2 = lista_blocos[j]

                for ponto1 in posicoes_validas(
                    BLOCOS[bloco1]
                ):

                    for ponto2 in posicoes_validas(
                        BLOCOS[bloco2]
                    ):

                        if sobrepoe(
                            bloco1,
                            ponto1,
                            bloco2,
                            ponto2
                        ):

                            clausulas.append([
                                -estado[
                                    (
                                        bloco1,
                                        ponto1,
                                        altura,
                                        tempo
                                    )
                                ],
                                -estado[
                                    (
                                        bloco2,
                                        ponto2,
                                        altura,
                                        tempo
                                    )
                                ]
                            ])


# Estabilidade
for tempo in range(HORIZONTE + 1):

    for bloco, comprimento in BLOCOS.items():

        apoio_minimo = (
            comprimento + 1
        ) // 2

        for ponto in posicoes_validas(comprimento):

            slots = list(
                range(
                    ponto,
                    ponto + comprimento
                )
            )

            for altura in range(
                1,
                NIVEL_MAXIMO + 1
            ):

                var_estado = estado[
                    (
                        bloco,
                        ponto,
                        altura,
                        tempo
                    )
                ]

                apoios = []

                for slot in slots:

                    apoios.append(
                        ocupado_slot[
                            (
                                slot,
                                altura - 1,
                                tempo
                            )
                        ]
                    )

                pelo_menos_k(
                    var_estado,
                    apoios,
                    apoio_minimo
                )


# Definicao de clr
for tempo in range(HORIZONTE + 1):

    for bloco, comprimento in BLOCOS.items():

        var_livre = livre[
            (bloco, tempo)
        ]

        for ponto in posicoes_validas(comprimento):

            for altura in range(
                NIVEL_MAXIMO + 1
            ):

                var_estado = estado[
                    (
                        bloco,
                        ponto,
                        altura,
                        tempo
                    )
                ]

                bloqueadores = []

                if altura < NIVEL_MAXIMO:

                    for outro, comp_outro in BLOCOS.items():

                        if outro == bloco:
                            continue

                        for ponto_outro in posicoes_validas(
                            comp_outro
                        ):

                            if sobrepoe(
                                bloco,
                                ponto,
                                outro,
                                ponto_outro
                            ):

                                bloqueadores.append(
                                    estado[
                                        (
                                            outro,
                                            ponto_outro,
                                            altura + 1,
                                            tempo
                                        )
                                    ]
                                )

                clausulas.append(
                    [
                        -var_estado,
                        var_livre
                    ]
                    + bloqueadores
                )

                for bloqueador in bloqueadores:

                    clausulas.append([
                        -var_estado,
                        -bloqueador,
                        -var_livre
                    ])


# Pre-condicoes e efeitos dos movimentos
for (
    bloco,
    destino,
    ponto_destino,
    tempo
), var_movimento in movimento.items():

    clausulas.append([
        -var_movimento,
        livre[
            (bloco, tempo)
        ]
    ])

    if destino == "T":

        clausulas.append([
            -var_movimento,
            posicao[
                (
                    bloco,
                    ponto_destino,
                    tempo + 1
                )
            ]
        ])

        clausulas.append([
            -var_movimento,
            nivel[
                (
                    bloco,
                    0,
                    tempo + 1
                )
            ]
        ])

        clausulas.append([
            -var_movimento,
            -estado[
                (
                    bloco,
                    ponto_destino,
                    0,
                    tempo
                )
            ]
        ])

        for outro, comp_outro in BLOCOS.items():

            if outro == bloco:
                continue

            for ponto_outro in posicoes_validas(
                comp_outro
            ):

                if sobrepoe(
                    bloco,
                    ponto_destino,
                    outro,
                    ponto_outro
                ):

                    clausulas.append([
                        -var_movimento,
                        -estado[
                            (
                                outro,
                                ponto_outro,
                                0,
                                tempo
                            )
                        ]
                    ])

    else:

        clausulas.append([
            -var_movimento,
            livre[
                (destino, tempo)
            ]
        ])

        clausulas.append([
            -var_movimento,
            -nivel[
                (
                    destino,
                    NIVEL_MAXIMO,
                    tempo
                )
            ]
        ])

        for ponto_destino_bloco in posicoes_validas(
            BLOCOS[destino]
        ):

            if not sobrepoe(
                bloco,
                ponto_destino,
                destino,
                ponto_destino_bloco
            ):

                clausulas.append([
                    -var_movimento,
                    -posicao[
                        (
                            destino,
                            ponto_destino_bloco,
                            tempo
                        )
                    ]
                ])

        for altura_destino in range(
            NIVEL_MAXIMO
        ):

            clausulas.append([
                -var_movimento,
                -nivel[
                    (
                        destino,
                        altura_destino,
                        tempo
                    )
                ],
                nivel[
                    (
                        bloco,
                        altura_destino + 1,
                        tempo + 1
                    )
                ]
            ])

            clausulas.append([
                -var_movimento,
                -nivel[
                    (
                        destino,
                        altura_destino,
                        tempo
                    )
                ],
                -estado[
                    (
                        bloco,
                        ponto_destino,
                        altura_destino + 1,
                        tempo
                    )
                ]
            ])

            for outro, comp_outro in BLOCOS.items():

                if outro == bloco:
                    continue

                for ponto_outro in posicoes_validas(
                    comp_outro
                ):

                    if sobrepoe(
                        bloco,
                        ponto_destino,
                        outro,
                        ponto_outro
                    ):

                        clausulas.append([
                            -var_movimento,
                            -nivel[
                                (
                                    destino,
                                    altura_destino,
                                    tempo
                                )
                            ],
                            -estado[
                                (
                                    outro,
                                    ponto_outro,
                                    altura_destino + 1,
                                    tempo
                                )
                            ]
                        ])

        clausulas.append([
            -var_movimento,
            posicao[
                (
                    bloco,
                    ponto_destino,
                    tempo + 1
                )
            ]
        ])


# Frame axioms
for tempo in range(HORIZONTE):

    for bloco, comprimento in BLOCOS.items():

        movimentos_bloco = []

        for (
            b,
            destino,
            ponto,
            t
        ), var in movimento.items():

            if b == bloco and t == tempo:
                movimentos_bloco.append(var)

        for ponto in posicoes_validas(comprimento):

            clausulas.append(
                [
                    -posicao[
                        (
                            bloco,
                            ponto,
                            tempo
                        )
                    ],
                    posicao[
                        (
                            bloco,
                            ponto,
                            tempo + 1
                        )
                    ]
                ]
                + movimentos_bloco
            )

        for altura in range(
            NIVEL_MAXIMO + 1
        ):

            clausulas.append(
                [
                    -nivel[
                        (
                            bloco,
                            altura,
                            tempo
                        )
                    ],
                    nivel[
                        (
                            bloco,
                            altura,
                            tempo + 1
                        )
                    ]
                ]
                + movimentos_bloco
            )


# Uma acao por passo
for tempo in range(HORIZONTE):

    acoes = []

    for (
        bloco,
        destino,
        ponto,
        t
    ), var in movimento.items():

        if t == tempo:
            acoes.append(var)

    exatamente_uma(acoes)


def gerar_cnf():
    total_variaveis = proxima_variavel - 1

    with open(
        ARQUIVO_CNF,
        "w",
        encoding="utf-8"
    ) as arquivo:

        arquivo.write(
            f"p cnf {total_variaveis} "
            f"{len(clausulas)}\n"
        )

        for clausula in clausulas:

            arquivo.write(
                " ".join(
                    str(valor)
                    for valor in clausula
                )
            )

            arquivo.write(" 0\n")


def gerar_mapa():
    with open(
        ARQUIVO_MAPA,
        "w",
        encoding="utf-8"
    ) as arquivo:

        for identificador in sorted(
            mapa_variaveis
        ):

            arquivo.write(
                f"{identificador} "
                f"{mapa_variaveis[identificador]}\n"
            )


def main():
    gerar_cnf()
    gerar_mapa()

    print(
        f"Gerado: {proxima_variavel - 1} variaveis, "
        f"{len(clausulas)} clausulas"
    )

    print(
        f"Arquivos: {ARQUIVO_CNF}, "
        f"{ARQUIVO_MAPA}"
    )


if __name__ == "__main__":
    main()