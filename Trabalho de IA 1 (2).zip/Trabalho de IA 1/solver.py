from pysat.formula import CNF
from pysat.solvers import Minisat22


ARQUIVO_CNF = "trab01_blocos2SAT.cnf"
ARQUIVO_RESULTADO = "resultado1.txt"


def carregar_formula():
    return CNF(from_file=ARQUIVO_CNF)


def resolver_formula(formula):
    with Minisat22(bootstrap_with=formula.clauses) as solver:
        satisfativel = solver.solve()

        if satisfativel:
            return True, solver.get_model()

        return False, []


def salvar_resultado(satisfativel, modelo):
    with open(ARQUIVO_RESULTADO, "w", encoding="utf-8") as arquivo:

        if satisfativel:
            arquivo.write("SAT\n")
            arquivo.write(
                " ".join(str(literal) for literal in modelo)
            )
            arquivo.write(" 0\n")

        else:
            arquivo.write("UNSAT\n")


def main():
    print("Carregando CNF...")

    formula = carregar_formula()

    print(f"Variáveis: {formula.nv}")
    print(f"Cláusulas: {len(formula.clauses)}")

    print("\nExecutando MiniSat22...")

    satisfativel, modelo = resolver_formula(formula)

    if satisfativel:
        print("\nSATISFIABLE")
        print("Plano encontrado.")
    else:
        print("\nUNSATISFIABLE")
        print("Nenhum plano encontrado para este horizonte.")

    salvar_resultado(satisfativel, modelo)

    print(f"\nResultado salvo em: {ARQUIVO_RESULTADO}")


if __name__ == "__main__":
    main()